import { User } from './user.model';
import { MentorId } from './mentor.model';

export interface Booking {
   userId: string;
   email: string;
   date: string;
   slot: string;
   platform: string;
   user: User;
   mentor: MentorId;
}