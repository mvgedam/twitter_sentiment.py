export interface User {
    name: string;
    phone: string;
    city: string;
    jeeYear: number;
  }