export interface Mentor {
    imageURL: string;
    name: string;
    batch: string;
    college: string;
    branch: string;
    city: string;
}

export interface MentorId extends Mentor { id: string; }