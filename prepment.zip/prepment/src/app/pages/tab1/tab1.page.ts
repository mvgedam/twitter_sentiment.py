import { Component } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MentorId, Mentor} from '../../models/mentor.model';
import { map } from 'rxjs/operators';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  mentors: Observable<MentorId[]>;
  firestoreMentorsCollection = this.firestore.collection<Mentor>('mentors');
  constructor(private firestore: AngularFirestore, private router: Router, private authService: AuthService) {
    this.mentors = this.firestoreMentorsCollection.snapshotChanges().pipe(
      map(actions => actions.map(a => {
        const data = a.payload.doc.data() as Mentor;
        const id = a.payload.doc.id;
        return {id, ...data};
      }))
    );
  }

  async ngOnInit() {
    if (await this.authService.getUser() == null) {
      this.router.navigate(['/login'], {replaceUrl: true});
    }
  }

  async bookSlot(mentor: MentorId) {
    var mentorJSON = JSON.stringify(mentor);
    localStorage.setItem("mentor", mentorJSON);
    this.router.navigate(['/slot'], {replaceUrl: true});
  }
}
