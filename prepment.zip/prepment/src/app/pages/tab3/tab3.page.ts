import { Component } from '@angular/core';
import {AuthService} from "../../services/auth.service";
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Booking } from 'src/app/models/booking.model';
import { AngularFirestore } from '@angular/fire/firestore';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {

  bookings: Observable<Booking[]>

  firestoreBookingsCollection = this.firestore.collection('bookings', ref => {
    let query : firebase.firestore.CollectionReference | firebase.firestore.Query = ref;
    query = query.where('userId', '==', localStorage.getItem("uid"))
    return query;
  });

  constructor(private authService: AuthService, private router: Router, private firestore: AngularFirestore) {
    this.bookings = this.firestoreBookingsCollection.snapshotChanges().pipe(
      map(actions => actions.map(a => {
        const data = a.payload.doc.data() as Booking;
        const id = a.payload.doc.id;
        console.log(data);
        return {id, ...data};
      }))
    );
  }

  async logout() {
    await this.authService.logout();
    this.router.navigate(['/login'], {replaceUrl: true});
  }
}
