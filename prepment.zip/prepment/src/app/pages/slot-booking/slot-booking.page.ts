import { Component, OnInit } from '@angular/core';
import {AuthService} from '../../services/auth.service';
import { Booking } from '../../models/booking.model';
import { AngularFirestore } from '@angular/fire/firestore';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user.model';
import { MentorId } from 'src/app/models/mentor.model';


@Component({
  selector: 'app-slot-booking',
  templateUrl: './slot-booking.page.html',
  styleUrls: ['./slot-booking.page.scss'],
})
export class SlotBookingPage implements OnInit {

  today: string =  "";
  tomorrow: string =  "";
  dayAfter: string = ""; 

  date: string = "";
  slot: string = "";
  platform: string = "";

  currentDate: string = new Date().toISOString();

  firestoreBookingsCollection = this.firestore.collection('bookings');

  constructor(private firebaseAuth: AuthService, private firestore: AngularFirestore, private router: Router) { }

  ngOnInit() {
    var days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    var today = new Date();
    this.today =
      today.getDate().toString() +
      "/" +
      (today.getMonth() + 1).toString() +
      "\n - " +
      days[today.getDay()];

    var tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);
    this.tomorrow =
      tomorrow.getDate().toString() +
      "/" +
      (tomorrow.getMonth() + 1).toString() +
      "\n - " +
      days[tomorrow.getDay()];

    var dayAfter = new Date();
    dayAfter.setDate(today.getDate() + 2);
    this.dayAfter =
      dayAfter.getDate().toString() +
      "/" +
      (dayAfter.getMonth() + 1).toString() +
      "\n - " +
      days[dayAfter.getDay()];
  }

  async selectDate(date: string) {
    this.date = date;
  }

  async selectSlot(slot: string) {
    this.slot = slot;
  }

  async setPlatform(platform:string) {
    this.platform = platform;
  }

  async bookSlot() {
    var user: User = JSON.parse(localStorage.getItem("user"));
    var mentor: MentorId = JSON.parse(localStorage.getItem("mentor"));

    var slot: Booking =  {
      userId: (await this.firebaseAuth.getUser()).uid,
      email: (await this.firebaseAuth.getUser()).email,
      slot: this.slot,
      date: this.date,
      platform: this.platform,
      user: user,
      mentor: mentor
    }

    try {
      var res = await this.firestoreBookingsCollection.add(slot);
      this.router.navigate(['/app/account'], {replaceUrl: true});
    } catch (err) {
      console.log(err);
      return err
    }


  }

}
