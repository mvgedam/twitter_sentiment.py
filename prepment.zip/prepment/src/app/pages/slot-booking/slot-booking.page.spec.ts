import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SlotBookingPage } from './slot-booking.page';

describe('SlotBookingPage', () => {
  let component: SlotBookingPage;
  let fixture: ComponentFixture<SlotBookingPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SlotBookingPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SlotBookingPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
