import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { AngularFirestore } from '@angular/fire/firestore';
import { User } from '../../models/user.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-onboarding',
  templateUrl: './onboarding.page.html',
  styleUrls: ['./onboarding.page.scss'],
})
export class OnboardingPage implements OnInit {

  user: User = {name: "", phone: "", jeeYear: 2020, city: ""};

  constructor(private router: Router, private firestore: AngularFirestore, private authService: AuthService, private http: HttpClient) { }

  firestoreUsersCollection = this.firestore.collection('users');

  async ngOnInit() {
    if (this.authService.isRegistered()) {
      this.router.navigate(['/app/mentor'], {replaceUrl: true});   
    }
  }

  async addUser(): Promise<void> {
    try {
      let headers = new HttpHeaders({
        "Content-Type": "application/json",
        idToken: await this.authService.getToken(),
      })

      this.http.post("https://us-central1-exampad-dev.cloudfunctions.net/users/onboarding", null, {
        headers: headers
      }).subscribe(async (res: any) => {
        console.log(res);
        await this.firestoreUsersCollection.add(this.user);
        localStorage.setItem("user", JSON.stringify(this.user));
        this.router.navigate(['/app/mentor'], {replaceUrl: true});
      })
    } catch (err) {
      console.log(err);
      return err
    }
  }
}
