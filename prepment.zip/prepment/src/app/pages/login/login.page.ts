import { Component, OnInit } from '@angular/core';
import { AuthService } from "../../services/auth.service"
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  smsSent: boolean = false;
  
  constructor(private authService: AuthService, private router: Router) {
  }

  async ngOnInit() {
    if (await this.authService.getUser() != null) {
      if (this.authService.isRegistered()) {
        this.router.navigate(['/app/mentor'], {replaceUrl: true});   
      } else {
        this.router.navigate(['/onboarding'], {replaceUrl: true}); 
      }
    }   
  }

  async loginWithGoogle(){
    var res = await this.authService.GoogleAuth();
    console.log(res);
    var uid = (await this.authService.getUser()).uid;
    localStorage.setItem("uid", uid);
    this.router.navigate(['/onboarding'], {replaceUrl: true});   
  }
}
