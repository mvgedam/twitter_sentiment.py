import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { Observable } from 'rxjs';
import { first } from 'rxjs/operators';
import { auth } from "firebase/app";

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  user: Observable<firebase.User>;
  confirmationResult: any;
  
  constructor(private firebaseAuth: AngularFireAuth) { 
  }

  async GoogleAuth() {
    return await this.AuthLogin(new auth.GoogleAuthProvider());
  }  

  // Auth logic to run auth providers
  async AuthLogin(provider: any) {
    try {
      var result = await this.firebaseAuth.signInWithPopup(provider)
      console.log('You have been successfully logged in!');
      return result;
    } catch (err) {
      console.log(err);
      return err;
    }
  }

  async logout() {
    try {
      var result = await this.firebaseAuth.signOut()
      console.log("Successfully Logged out..", result)
    } catch (err) {
      console.log(err);
      return err;
    }
  }

  async getUser() {
    var user = this.firebaseAuth.authState.pipe(first()).toPromise();
    return user;
  }

  async getToken() {
    var user = await this.firebaseAuth.currentUser;
    var token = await user.getIdToken(true);
    return token;
  }

  async isRegistered() {
    var res = (await this.firebaseAuth.currentUser).getIdTokenResult();
    var isRegistered = (await res).claims.registered;
    return isRegistered;
  }

}
